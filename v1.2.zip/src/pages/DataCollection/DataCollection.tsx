import Layout from "@Obitech/components/layout/Layout"
import ContentContainer from "@Obitech/components/misc/ContentContainer"
import { ArrowLeftIcon } from "@heroicons/react/24/solid"
import React from "react"
import { Link, useNavigate } from "react-router-dom"

export default function DataCollection() {
	const router = useNavigate()
	const handleSubmit = (e: React.ChangeEvent<HTMLFormElement>) => {
		e?.preventDefault()

		router("/personal-info")
	}
	return (
		<Layout>
			<ContentContainer>
				<section className="my-5 grid grid-cols-1 gap-4">
					<head className="grid lg:grid-cols-3 gap-4 mb-5">
						<div className="">
							<Link to={"/dashboard"} className="flex gap-2 text-slate-800">
								<ArrowLeftIcon className="0" width={24} height={24} /> <span>Back</span>
							</Link>
						</div>

						<div className="col-span-2">
							<h1 className="text-2xl font-bold text-blue">Employee Information</h1>
						</div>
					</head>

					<section className="">
						<form onSubmit={handleSubmit} action="/perosnal-info" className="">
							<div className="grid lg:grid-cols-2 xs:grid-cols-1 gap-4">
								<div className="">
									<label htmlFor="employeeStatus" className="mb-3 block">
										Employee Status *
									</label>
									<select required className="p-3 rounded bg-slate-300 block w-full">
										<optgroup>
											<option value={"Item"}>Item</option>
										</optgroup>
									</select>
								</div>

								<div className="">
									<label htmlFor="employeeStatus" className="mb-3 block">
										Employee Type *
									</label>
									<select required className="p-3 rounded bg-slate-300 block w-full">
										<optgroup>
											<option value={"Item"}>Item</option>
										</optgroup>
									</select>
								</div>

								<div className="">
									<label htmlFor="employeeStatus" className="mb-3 block">
										Employee's Name *
									</label>
									<input required className="p-3 rounded bg-slate-300 block w-full" />
								</div>

								<div className="">
									<label htmlFor="employeeStatus" className="mb-3 block">
										Employee's Address*
									</label>
									<input required className="p-3 rounded bg-slate-300 block w-full" />
								</div>

								<div className="">
									<label htmlFor="employeeStatus" className="mb-3 block">
										Country *
									</label>
									<select required className="p-3 rounded bg-slate-300 block w-full">
										<optgroup>
											<option value={"Item"}>Item</option>
										</optgroup>
									</select>
								</div>

								<div className="">
									<label htmlFor="employeeStatus" className="mb-3 block">
										State *
									</label>
									<select required className="p-3 rounded bg-slate-300 block w-full">
										<optgroup>
											<option value={"Item"}>Item</option>
										</optgroup>
									</select>
								</div>

								<div className="">
									<label htmlFor="employeeStatus" className="mb-3 block">
										Nature of Business*
									</label>
									<select required className="p-3 rounded bg-slate-300 block w-full">
										<optgroup>
											<option value={"Item"}>Item</option>
										</optgroup>
									</select>
								</div>

								<div className="">
									<label htmlFor="employeeStatus" className="mb-3 block">
										Business Sectore Classification *
									</label>
									<select required className="p-3 rounded bg-slate-300 block w-full">
										<optgroup>
											<option value={"Item"}>Item</option>
										</optgroup>
									</select>
								</div>
							</div>

							<div className="my-4 flex items-center justify-end">
								<button className="p-3 rounded bg-blue text-slate-100 text-center">Save & Continue</button>
							</div>
						</form>
					</section>
				</section>
			</ContentContainer>
		</Layout>
	)
}
