import PageContainer from "@Obitech/components/misc/PageContainer"
import React from "react"

export default function NotificationPage() {
	return (
		<PageContainer goBackUrl="/dashboard">
			<section className="">
				<h1 className="font-bold text-lg my-4">Notification</h1>
			</section>
		</PageContainer>
	)
}
