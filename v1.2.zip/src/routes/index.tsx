import DataCollection from "@Obitech/pages/DataCollection/DataCollection"
import PersonalInfomationPage from "@Obitech/pages/DataCollection/PersonalInformation"
import UploadDataPage from "@Obitech/pages/DataCollection/UploadData"
import Dashboard from "@Obitech/pages/dashboard/Dashboard"
import Login from "@Obitech/pages/login/Login"
import NotificationPage from "@Obitech/pages/settings/Notification"
import { createBrowserRouter } from "react-router-dom"

export const AppRoutes = createBrowserRouter([
	{
		path: "/",
		element: <Login />
	},
	{
		path: "/login",
		element: <Login />
	},
	{
		path: "/dashboard",
		element: <Dashboard />
	},

	{
		path: "/data-collection",
		element: <DataCollection />
	},

	{
		path: "/personal-info",
		element: <PersonalInfomationPage />
	},
	{
		path: "/upload-data",
		element: <UploadDataPage />
	},
	{
		path: "/notification",
		element: <NotificationPage />
	}
])
