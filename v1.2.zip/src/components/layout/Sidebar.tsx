import React from "react"
import { AdjustmentsHorizontalIcon } from "@heroicons/react/24/solid"
import { ArrowRightOnRectangleIcon, BellAlertIcon, ChartBarSquareIcon, ClipboardDocumentCheckIcon, Cog8ToothIcon, UsersIcon } from "@heroicons/react/24/outline"
import { Link } from "react-router-dom"
import UserImg from "@Obitech/assets/img/user.png"

export default function Sidebar() {
	return (
		<div className="oti_sidebar h-full relative col-span-1 md:block xs:hidden">
			<h3 className="flex flex-row items-center font-bold text-slate-200 text-lg p-3">
				<AdjustmentsHorizontalIcon width={24} height={24} className="mr-3 text-slate-400" /> Data Collection
			</h3>

			<div className="mt-10 pl-3 flex flex-col justify-between h-full overflow-y-scroll relative">
				<ul className="flex flex-col gap-4">
					<li className="">
						<Link to={"/dashboard"} className="text-slate-300 p-2 py-4 rounded-s-3xl w-full flex items-center hover:text-blue hover:bg-slate-100 active:text-blue active:bg-slate-100">
							<ChartBarSquareIcon width={24} height={24} className="mr-2" /> <span>Dashboard</span>
						</Link>
					</li>

					<li className="">
						<Link to={"#"} className="text-slate-300 p-2 py-4 rounded-s-3xl w-full flex items-center hover:text-blue hover:bg-slate-100 active:text-blue active:bg-slate-100">
							<ClipboardDocumentCheckIcon width={24} height={24} className="mr-2" /> <span>Task</span>
						</Link>
					</li>

					<li className="">
						<Link to={"#"} className="text-slate-300 p-2 py-4 rounded-s-3xl w-full flex items-center hover:text-blue hover:bg-slate-100 active:text-blue active:bg-slate-100">
							<UsersIcon width={24} height={24} className="mr-2" /> <span>My Team</span>
						</Link>
					</li>
				</ul>

				<ul className="flex flex-col gap-2">
					<li className="">
						<Link to={"#"} className="text-slate-300 p-2 py-4 rounded-s-3xl w-full flex items-center hover:text-slate-200">
							<Cog8ToothIcon width={24} height={24} className="mr-2" /> <span>Settings</span>
						</Link>
					</li>

					<li className="">
						<Link to={"/notification"} className="text-slate-300 p-2 py-4 rounded-s-3xl w-full flex items-center hover:text-slate-200">
							<BellAlertIcon width={24} height={24} className="mr-2" /> <span>Notification</span>
						</Link>
					</li>

					<li className="">
						<Link to={"#"} className="text-slate-300 p-2 py-4 rounded-s-3xl w-full flex gap-2 items-center hover:text-slate-200">
							<img src={UserImg} alt="User" className="w-[40px] h-[40px] rounded-full" /> <span>Obi Pascal Banjuare</span> <ArrowRightOnRectangleIcon width={24} height={24} className="mr-2" />
						</Link>
					</li>
				</ul>
			</div>
		</div>
	)
}
